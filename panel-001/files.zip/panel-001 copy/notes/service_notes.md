# Service Notes for Panel-001

- Installed: Jan 2024
- Latest inspection: Apr 2025
- Issue history:
  - Feb 2025: Replaced faulty relay K2
